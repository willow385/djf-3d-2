Documentation will go here once I've written it. For now,
you'll have to just read the header files to learn how to
use it; they are filled with detailed javadoc-style
documentation comments. Hey, at least you don't need to
read the source files.