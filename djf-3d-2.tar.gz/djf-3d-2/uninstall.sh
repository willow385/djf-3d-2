#!/bin/bash
rm -rf /usr/include/djf-3d-2
rm /usr/lib/libdjf-3d-2.a