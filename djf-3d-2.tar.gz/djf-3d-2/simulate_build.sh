docker build -t djf-3d-2 .
docker run -it djf-3d-2 bash main.sh
